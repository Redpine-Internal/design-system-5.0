# Design Fidelity Checklist

> Use this checklist to validate that components follow the design spec.
> Reference: `squads/super-agentes/data/design-tokens-spec.yaml`

---

## Pre-Validation

### Load Spec
- [ ] Read `design-tokens-spec.yaml` completely
- [ ] Identify relevant tokens for the component
- [ ] Note expected values

### Identify Component
- [ ] Component type: _____________ (button, input, card, modal, etc.)
- [ ] Variants: _____________ (primary, secondary, outline, etc.)
- [ ] States: _____________ (default, hover, focus, disabled, etc.)

---

## Color Validation

### Primary Colors
- [ ] Primary color uses `studio-primary` or `var(--primary-color)`
- [ ] Hover uses `studio-primary-dark` or `var(--primary-dark)`
- [ ] NEVER hardcoded `#D4AF37` or `#B8962E`

### Background Colors
- [ ] Main background uses `studio-bg` or `bg-background`
- [ ] Cards use `studio-card-bg` or `bg-card`
- [ ] Surfaces use `bg-surface` or `bg-[#1a1a1f]` with comment
- [ ] NEVER hardcoded `#0A0A0F` or `#111116` without justification

### Text Colors
- [ ] Primary text uses `text-foreground` or `text-white`
- [ ] Secondary text uses `text-muted-foreground` or `text-studio-text-secondary`
- [ ] Muted text uses `text-muted` or `text-studio-text-muted`

### Semantic Colors
- [ ] Success uses `text-green-500` or `status-success`
- [ ] Warning uses `text-yellow-500` or `status-warning`
- [ ] Error uses `text-red-500` or `status-error`
- [ ] Info uses `text-blue-500` or `status-info`

### Automated Validation
```bash
# Run and verify 0 results
grep -rn "#D4AF37\|#B8962E\|#0A0A0F\|#111116" {component}/
```
- [ ] Command executed, 0 results

---

## Typography Validation

### Font Family
- [ ] UI text uses `font-sans` (Inter)
- [ ] Headings use `font-display` (Rajdhani) if applicable
- [ ] Code uses `font-mono` (JetBrains Mono)

### Font Size
| Use | Token | Tailwind | Check |
|-----|-------|----------|-------|
| Caption | xs | text-xs | [ ] |
| Button/Secondary | sm | text-sm | [ ] |
| Body | base | text-base | [ ] |
| Lead | lg | text-lg | [ ] |
| Heading | xl-5xl | text-xl to text-5xl | [ ] |

### Font Weight
- [ ] Body text: `font-normal` (400)
- [ ] Buttons: `font-medium` (500)
- [ ] Headings: `font-semibold` (600)
- [ ] Emphasis: `font-bold` (700)

### Line Height
- [ ] Short text: `leading-tight` or `leading-5`
- [ ] Body text: `leading-normal` or `leading-6`
- [ ] Large headings: `leading-none` or `leading-tight`

---

## Spacing Validation

### Padding
| Context | Token | Tailwind | Check |
|---------|-------|----------|-------|
| Tight | 1-2 | p-1, p-2 | [ ] |
| Small | 3 | p-3 | [ ] |
| Standard | 4 | p-4 | [ ] |
| Medium | 5-6 | p-5, p-6 | [ ] |
| Large | 8+ | p-8+ | [ ] |

### Gap/Spacing
- [ ] List items: `gap-2` or `gap-3`
- [ ] Sections: `gap-4` or `gap-6`
- [ ] Groups: `gap-6` or `gap-8`
- [ ] Larger sections: `gap-8` or `gap-12`

### Automated Validation
```bash
# Check hardcoded pixel values
grep -rn "p-\[.*px\]\|m-\[.*px\]\|gap-\[.*px\]" {component}/
```
- [ ] Command executed, 0 results (or justified)

---

## Border and Radius Validation

### Border Width
- [ ] Default: `border` (1px)
- [ ] Emphasis: `border-2` (2px)
- [ ] NEVER `border-[3px]` or arbitrary values

### Border Radius
| Component | Token | Tailwind | Check |
|-----------|-------|----------|-------|
| Badge | sm | rounded-sm | [ ] |
| Button | md | rounded-md | [ ] |
| Input | md | rounded-md | [ ] |
| Card | lg-xl | rounded-lg or rounded-xl | [ ] |
| Modal | 2xl | rounded-2xl | [ ] |
| Avatar/Pill | full | rounded-full | [ ] |

### Border Color
- [ ] Default: `border-border` or `border-white/10`
- [ ] Primary: `border-studio-primary/50` or `border-[var(--primary-color)]/50`
- [ ] Subtle: `border-white/5`

---

## Shadow Validation

- [ ] No shadow: `shadow-none`
- [ ] Subtle: `shadow-sm`
- [ ] Card/Dropdown: `shadow-md`
- [ ] Modal: `shadow-lg` or `shadow-xl`
- [ ] Primary glow: custom with `rgba(212, 175, 55, 0.3)`

---

## Motion Validation

### Duration
- [ ] Micro-interactions: `duration-100` (fast)
- [ ] Standard: `duration-200` (normal)
- [ ] Page transitions: `duration-300` (slow)

### Easing
- [ ] Enter: `ease-out`
- [ ] Exit: `ease-in`
- [ ] Standard: `ease-in-out`

### Transitions
- [ ] Hover states: `transition-colors duration-200`
- [ ] Transform: `transition-transform duration-200`
- [ ] All: `transition-all duration-200`

---

## Contrast Validation (WCAG AA)

### Normal Text (< 18px)
Minimum: **4.5:1**

| Combination | Ratio | Status |
|-------------|-------|--------|
| text-white on bg-base | ~15:1 | [ ] OK |
| text-secondary on bg-base | ~7:1 | [ ] OK |
| text-muted on bg-base | ~4.5:1 | [ ] Check |
| text-muted on bg-elevated | ~3.8:1 | [ ] WARN |

### Large Text (>= 18px or 14px bold)
Minimum: **3.0:1**

### UI Components
Minimum: **3.0:1**

### Verification Tool
```bash
# Use WebAIM Contrast Checker or similar
# https://webaim.org/resources/contrastchecker/
```

---

## Specific Component Validation

### Button
- [ ] Padding: `py-2 px-4` (sm), `py-2.5 px-5` (md), `py-3 px-6` (lg)
- [ ] Border radius: `rounded-md`
- [ ] Font: `text-sm font-medium`
- [ ] Min height: 32px (sm), 40px (md), 48px (lg)
- [ ] Primary: `bg-studio-primary text-studio-bg hover:bg-studio-primary-dark`
- [ ] Focus ring: `focus:ring-2 focus:ring-studio-primary/50`

### Input
- [ ] Height: 32px (sm), 40px (md), 48px (lg)
- [ ] Padding: `py-2 px-3`
- [ ] Border: `border border-white/10`
- [ ] Background: `bg-surface` or `bg-[#1a1a1f]`
- [ ] Focus: `focus:ring-2 focus:ring-studio-primary/50`

### Card
- [ ] Padding: `p-4` (sm), `p-6` (md), `p-8` (lg)
- [ ] Border radius: `rounded-xl`
- [ ] Background: `bg-card` or `bg-studio-card-bg`
- [ ] Border: `border border-white/10`

### Modal
- [ ] Max width: 384px (sm), 448px (md), 512px (lg)
- [ ] Padding: `p-6`
- [ ] Border radius: `rounded-2xl`
- [ ] Background: `bg-card`
- [ ] Overlay: `bg-black/80`

---

## Success Metrics

| Metric | Criterion | Check |
|--------|-----------|-------|
| Hardcoded colors | 0 | [ ] |
| Hardcoded spacing | 0 (or justified) | [ ] |
| Contrast violations | 0 | [ ] |
| Wrong token usage | 0 | [ ] |
| Visual match to spec | 100% | [ ] |

---

## Quick Validation Commands

```bash
# 1. Hardcoded colors
grep -rn "#[0-9A-Fa-f]\{6\}" {component}/ | grep -v "node_modules\|\.yaml\|\.json"

# 2. Hardcoded spacing
grep -rn "\[.*px\]" {component}/ | grep -E "p-|m-|gap-|w-|h-"

# 3. Hardcoded font sizes
grep -rn "text-\[" {component}/

# 4. Correct imports
grep -rn "from '@/components/ui" {component}/
```

---

*Checklist v1.0 - Based on design-tokens-spec.yaml v1.0.0*

---

## Scoring

### Point System
Each checkbox item = 1 point.

| Category | Items | Weight |
|----------|-------|--------|
| Pre-Validation | 6 | 6pts |
| Color Validation | 15 | 15pts |
| Typography Validation | 15 | 15pts |
| Spacing Validation | 10 | 10pts |
| Border and Radius Validation | 12 | 12pts |
| Shadow Validation | 5 | 5pts |
| Motion Validation | 9 | 9pts |
| Contrast Validation | 4 | 4pts |
| Specific Component Validation | 20 | 20pts |
| Success Metrics | 5 | 5pts |
| **Total** | **101** | **101pts** |

### Pass/Fail Thresholds
| Grade | Score | Action |
|-------|-------|--------|
| PASS | >= 80% (81+) | Proceed to next phase |
| CONDITIONAL | 60-79% (61-80) | Fix critical items, re-check |
| FAIL | < 60% (60-) | Major rework required |

### Auto-Correction
If items fail:
- Run `*ds-extract-tokens` to identify hardcoded values. Use `*contrast-matrix` for color issues.
