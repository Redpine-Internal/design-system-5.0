# Reading Accessibility Checklist

> Use this checklist to validate digital reading experiences.
> Reference: `squads/super-agentes/data/high-retention-reading-guide.md`

---

## 1. Typography — CRITICAL

### Font Size
- [ ] Body text ≥ 16px (WCAG minimum)
- [ ] Ideal for reading: 18-21px
- [ ] Captions/footnotes ≥ 11px
- [ ] Labels/metadata ≥ 13px

### Line Height
- [ ] Body text: line-height ≥ 1.5
- [ ] Ideal for reading: 1.6
- [ ] Headings: 1.25-1.375
- [ ] Code: 1.5-1.625

### Line Length
- [ ] WCAG maximum: 80ch
- [ ] Ideal: 65ch
- [ ] Mobile: 35-50ch
- [ ] Desktop: 60-75ch

### Font Weight
- [ ] Body text: ≥ 400 (Regular)
- [ ] Never use light (300) for body
- [ ] Headings: 600-700

### Letter Spacing
- [ ] Letter-spacing: ~0.012em (0.12x)
- [ ] Mobile: consider 0.016em
- [ ] User-adjustable

### Alignment
- [ ] Text left-aligned (NEVER justified)
- [ ] Headings may be centered
- [ ] No ALL CAPS in text blocks
- [ ] No italics in long blocks

### Scalability
- [ ] Text can be zoomed to 200% without loss
- [ ] Zoom works without breaking layout
- [ ] No text in images (except logos)

---

## 2. Color and Contrast — WCAG

### Text Contrast
- [ ] Normal text: ≥ 4.5:1 (AA)
- [ ] Large text (≥18px bold or ≥24px): ≥ 3:1
- [ ] Ideal for extended reading: 7:1 (AAA)
- [ ] Links vs surrounding text: ≥ 3:1

### Light Mode
- [ ] Background: off-white (#FAFAFA to #F5F5F5)
- [ ] Do NOT use pure white (#FFFFFF) for body
- [ ] Text: #212121 to #424242

### Dark Mode
- [ ] Background: #121212 to #1E1E1E
- [ ] NEVER use pure black (#000000)
- [ ] Text: #E0E0E0 to #EDEDED
- [ ] NEVER use pure white (#FFFFFF)
- [ ] Avoid 21:1 contrast (causes halation)

### Theme Options
- [ ] Light theme available
- [ ] Dark theme available
- [ ] Sepia/cream theme available (ideal for 2+ hours)
- [ ] "Follow system" option (prefers-color-scheme)

### Links
- [ ] Distinguishable beyond color (underline, weight, icon)
- [ ] Contrast ≥ 3:1 with surrounding text
- [ ] Visited state differentiated
- [ ] Hover state visible

### Highlights
- [ ] 40% opacity to maintain readability
- [ ] Multiple colors available
- [ ] Contrast maintained over highlight

---

## 3. Cognitive Accessibility

### Paragraphs
- [ ] 3-4 sentences per paragraph (max 5)
- [ ] One main idea per paragraph
- [ ] Avoid text blocks >5 lines

### Headings
- [ ] Every 3-5 paragraphs
- [ ] Logical hierarchy (H1 → H2 → H3)
- [ ] Descriptive of content
- [ ] Facilitate scanning

### Structure
- [ ] TL;DR/summary at the top (long-form)
- [ ] Table of Contents (>5 sections)
- [ ] Expandable/collapsible sections
- [ ] Inverted pyramid (conclusion first)

### Navigation
- [ ] Skip links available
- [ ] ARIA landmarks (main, nav, article)
- [ ] Keyboard navigation functional
- [ ] Logical tab order

---

## 4. Reading UI Elements

### Progress Indicator
- [ ] Progress bar visible (top or side)
- [ ] Or: numeric percentage
- [ ] Or: "X min remaining"
- [ ] Scroll depth tracked

### Reading Time
- [ ] Displayed for articles >500 words
- [ ] Format: "X min read"
- [ ] Calculation: words ÷ 200

### Save Position
- [ ] Reading position saved automatically
- [ ] "Continue where you left off" functional
- [ ] Reading history available

### Annotations
- [ ] Highlight in multiple colors
- [ ] Margin or inline notes
- [ ] Export annotations

---

## 5. Responsiveness

### Mobile (< 640px)
- [ ] Font size: 16px
- [ ] Line length: 35-50ch
- [ ] Lateral padding: ≥ 16px
- [ ] Line height: 1.6-1.7
- [ ] Touch targets: ≥ 44x44px

### Tablet (640-1023px)
- [ ] Font size: 17px
- [ ] Line length: 55-70ch
- [ ] Padding: 24px

### Desktop (≥ 1024px)
- [ ] Font size: 18px
- [ ] Line length: 60-75ch
- [ ] Padding: 32px

### Large (≥ 1280px)
- [ ] Font size: 18-21px
- [ ] Line length: 65-80ch
- [ ] Padding: 40px

---

## 6. System Preferences

### Motion
- [ ] Respects prefers-reduced-motion
- [ ] Animations can be disabled
- [ ] No forced auto-scroll
- [ ] No distracting parallax

### Contrast
- [ ] Respects prefers-contrast
- [ ] High contrast option available

### Theme
- [ ] Respects prefers-color-scheme
- [ ] Manual override available

### Media
- [ ] No forced auto-play
- [ ] Accessible media controls

---

## 7. Dyslexia Support

- [ ] Sans-serif font option
- [ ] OpenDyslexic or similar option
- [ ] Text NEVER justified
- [ ] Line height increasable (up to 1.8)
- [ ] Letter spacing increasable
- [ ] Word spacing increasable
- [ ] Backgrounds without patterns/textures
- [ ] Sepia theme available

---

## 8. Low Vision Support

- [ ] 200% zoom functional
- [ ] High contrast available
- [ ] Font size customizable
- [ ] Alt text on all images
- [ ] No text in images
- [ ] Focus visible (outline/ring)

---

## 9. Contrast Validation

### Tools
- WebAIM Contrast Checker: https://webaim.org/resources/contrastchecker/
- Coolors Contrast Checker: https://coolors.co/contrast-checker

### Validation Commands
```bash
# Check hardcoded colors that may have low contrast
grep -rn "#[0-9A-Fa-f]\{6\}" {path}/ --include="*.tsx" --include="*.css"

# Check for pure white/black usage (avoid in dark mode)
grep -rn "#FFFFFF\|#000000" {path}/ --include="*.tsx" --include="*.css"
```

---

## 10. Success Metrics

| Metric | Criterion | Check |
|--------|-----------|-------|
| Body font size | ≥16px | [ ] |
| Line height | ≥1.5 | [ ] |
| Line length | ≤80ch | [ ] |
| Contrast AA | ≥4.5:1 | [ ] |
| Contrast AAA | ≥7:1 | [ ] |
| Themes available | ≥2 | [ ] |
| Zoom 200% | Functional | [ ] |
| Progress indicator | Visible | [ ] |
| Skip links | Available | [ ] |
| Keyboard nav | Functional | [ ] |

---

## 11. Quick Validation Commands

```bash
# 1. Check hardcoded font sizes
grep -rn "font-size:" {path}/ | grep -E "1[0-5]px|[0-9]px"

# 2. Check low line-heights
grep -rn "line-height:" {path}/ | grep -E "1\.[0-4]|1$"

# 3. Check text-align: justify
grep -rn "text-align:\s*justify" {path}/

# 4. Check ALL CAPS
grep -rn "text-transform:\s*uppercase" {path}/

# 5. Check pure white/black
grep -rn "#FFFFFF\|#000000\|rgb(255,\s*255,\s*255)\|rgb(0,\s*0,\s*0)" {path}/

# 6. Check prefers-reduced-motion
grep -rn "prefers-reduced-motion" {path}/

# 7. Check prefers-color-scheme
grep -rn "prefers-color-scheme" {path}/
```

---

*Checklist v1.0.0 — Based on WCAG 2.1/2.2, Apple HIG, Material Design 3, and publisher best practices.*
