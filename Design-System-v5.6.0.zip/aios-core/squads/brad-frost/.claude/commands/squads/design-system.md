# /design-system - Brad Frost Design System v5.5.0

Activate the Design System Squad — multi-agent architecture with Design Chief orchestrator.

## Instructions

**Load the agent from `aios-core/squads/brad-frost/agents/design-chief.md` and follow its activation instructions.**

The Design Chief will triage your request and route to the appropriate specialist:
- **@brad-frost** (design-system-v5) — DS architecture, audit, build, tokens, a11y
- **@dan-mall** — Adoption strategy, stakeholder buy-in, ROI pitch
- **@dave-malouf** — DesignOps, maturity assessment, team topology, scaling
- **@brad-ops** — Execution engine, YOLO mode, parallel refactoring
- **@nano-banana** — AI image generation for DS visual assets

## Architecture

```
ORCHESTRATOR: @design-chief (triage + routing)
  ├── Tier 0 (Diagnostic):
  │   ├── @dave-malouf — DesignOps maturity, metrics, scaling
  │   └── @dan-mall — DS strategy, adoption, stakeholder pitch
  ├── Tier 1 (Execution):
  │   ├── @brad-frost — DS architecture, audit, build, govern
  │   ├── @brad-ops — Parallel execution, refactoring supervisor
  │   └── @nano-banana — AI image generation
  └── Out of Scope → /Brand, /ContentVisual
```

## Quick Reference

### Activate Squad
```bash
/design-system
```

### Direct Agent Activation
```bash
/design-system:design-system-v5    # Brad Frost directly
/design-system:dan-mall             # Dan Mall directly
/design-system:dave-malouf          # Dave Malouf directly
/design-system:brad-ops             # BradOps executor directly
```

## Workflows
```
Brownfield:    *audit → *consolidate → *tokenize → *migrate → *build
Greenfield:    *setup → *build → *compose → *document
Refactoring:   *refactor-plan → *refactor-execute
Accessibility: *a11y-audit → *contrast-matrix → *focus-order → *aria-audit
Audit-Only:    *audit → *shock-report → *calculate-roi
DS Metrics:    *ds-health → *bundle-audit → *token-usage → *dead-code
Agentic DS:    *agentic-audit → *agentic-setup
W3C Tokens:    *token-w3c → *token-modes
DesignOps:     *designops-assess → *designops-maturity → *designops-topology
```

## Key Commands (after activation)

### Brownfield (Audit & Consolidation)
| Command | Description |
|---------|-------------|
| `*audit {path}` | Scan codebase for UI pattern redundancies |
| `*consolidate` | Reduce patterns via HSL clustering |
| `*tokenize` | Generate design token system |
| `*migrate` | Create 4-phase migration strategy |
| `*shock-report` | Generate visual HTML report |
| `*calculate-roi` | Cost analysis and savings projection |

### Component Building
| Command | Description |
|---------|-------------|
| `*setup` | Initialize design system structure |
| `*build {component}` | Generate production-ready component |
| `*compose {molecule}` | Build molecule from atoms |
| `*extend {pattern}` | Add variant to existing component |
| `*document` | Generate pattern library docs |
| `*bootstrap-shadcn` | Setup shadcn/ui library |

### Accessibility
| Command | Description |
|---------|-------------|
| `*a11y-audit` | Full WCAG 2.2 audit |
| `*contrast-matrix` | Color contrast analysis |
| `*focus-order` | Focus order validation |
| `*aria-audit` | ARIA attributes audit |

### DesignOps (via @dave-malouf)
| Command | Description |
|---------|-------------|
| `*designops-assess` | DesignOps maturity assessment |
| `*designops-maturity` | Full maturity model evaluation |
| `*designops-topology` | Team topology recommendation |

### Strategy (via @dan-mall)
| Command | Description |
|---------|-------------|
| `*stakeholder-pitch` | Sell DS to leadership |
| `*adoption-strategy` | DS adoption roadmap |

### Refactoring & Maintenance
| Command | Description |
|---------|-------------|
| `*refactor-plan` | Plan atomic refactoring |
| `*refactor-execute` | Execute refactoring |
| `*yolo` | Toggle parallel execution mode |
| `*ds-health` | Design system health score |
| `*help` | Show all commands (52 total) |
| `*exit` | Exit context |

---

*Design System v5.5.0 — 6 agents | 67 tasks | 11 checklists | 7 workflows | 3 protocols*
*Score: 10/10 | Type: Expert | Entry: design-chief*
