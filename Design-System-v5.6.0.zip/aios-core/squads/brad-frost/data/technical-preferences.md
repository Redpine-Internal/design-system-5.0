# Technical Preferences (Fallback)

This file provides a local fallback for technical preferences used by squad agents.

Primary source (when available):
- `.aios-core/data/technical-preferences.md`

Fallback defaults:
- Stack-first decisions should prioritize existing project conventions.
- Prefer deterministic workflows over implicit assumptions.
- Accessibility and token governance are non-optional quality gates.
