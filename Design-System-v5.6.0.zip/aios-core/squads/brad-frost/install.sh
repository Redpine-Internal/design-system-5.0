#!/bin/bash
# ============================================================
# Brad Frost Design System Squad — Installer v5.5.0
# ============================================================
# Copies .claude/ infrastructure to project root so Claude Code
# auto-activates the squad when design topics are discussed.
#
# Usage:
#   cd aios-core/squads/brad-frost
#   bash install.sh                    # install to current project (3 levels up)
#   bash install.sh /path/to/project   # install to specific project
# ============================================================

set -e

SQUAD_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="${1:-$(cd "$SQUAD_DIR/../../.." && pwd)}"

echo "🎨 Brad Frost Design System Squad — Installer"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Squad:   $SQUAD_DIR"
echo "Target:  $PROJECT_ROOT"
echo ""

# --- 1. Slash commands ---
echo "→ Installing slash commands..."
mkdir -p "$PROJECT_ROOT/.claude/commands/squads"
cp "$SQUAD_DIR/.claude/commands/squads/design-system.md" \
   "$PROJECT_ROOT/.claude/commands/squads/design-system.md"
echo "  ✓ /design-system command installed"

# --- 2. CLAUDE.md (append or create) ---
echo "→ Installing CLAUDE.md auto-activation block..."
MARKER="# Design System Squad — Brad Frost"

if [ -f "$PROJECT_ROOT/.claude/CLAUDE.md" ]; then
  # Check if already installed
  if grep -q "$MARKER" "$PROJECT_ROOT/.claude/CLAUDE.md" 2>/dev/null; then
    echo "  ⚠ CLAUDE.md already contains squad block — skipping (delete block manually to reinstall)"
  else
    echo "" >> "$PROJECT_ROOT/.claude/CLAUDE.md"
    echo "" >> "$PROJECT_ROOT/.claude/CLAUDE.md"
    cat "$SQUAD_DIR/.claude/CLAUDE.md" >> "$PROJECT_ROOT/.claude/CLAUDE.md"
    echo "  ✓ Appended squad block to existing CLAUDE.md"
  fi
else
  mkdir -p "$PROJECT_ROOT/.claude"
  cp "$SQUAD_DIR/.claude/CLAUDE.md" "$PROJECT_ROOT/.claude/CLAUDE.md"
  echo "  ✓ Created new CLAUDE.md with squad block"
fi

# --- 3. Verify agent files exist ---
echo "→ Verifying agent files..."
AGENTS_OK=true
for agent in design-chief design-system-v5 brad-ops dan-mall dave-malouf nano-banana-generator; do
  if [ -f "$PROJECT_ROOT/aios-core/squads/brad-frost/agents/$agent.md" ]; then
    echo "  ✓ $agent.md"
  else
    echo "  ✗ $agent.md — MISSING"
    AGENTS_OK=false
  fi
done

if [ "$AGENTS_OK" = false ]; then
  echo ""
  echo "⚠ Some agent files are missing. Make sure you extracted the full zip first:"
  echo "  unzip Design-System-v5.5.0.zip -d $PROJECT_ROOT"
fi

# --- Done ---
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✓ Installation complete!"
echo ""
echo "How to use:"
echo "  1. Open Claude Code in your project"
echo "  2. Type /design-system to activate the squad"
echo "  3. Or just ask about design systems — auto-activation is ON"
echo ""
echo "Quick test:"
echo '  Ask: "audit my design system"'
echo '  Expected: Design Chief loads and routes to @brad-frost'
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
