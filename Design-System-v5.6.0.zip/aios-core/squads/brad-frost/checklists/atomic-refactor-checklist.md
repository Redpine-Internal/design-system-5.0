# Atomic Design Refactoring Checklist

> Use this checklist for each refactored component.
> Reference: `app/components/ops/users/` (OpsUsersTemplate)
>
> **v2.0 - Jan/2026:** Anti-over-engineering gates added.

---

## GATE 0: Should I Atomize? (BEFORE ANYTHING)

```bash
wc -l {file}
grep -c "useState" {file}
```

| Lines | useState | Decision |
|-------|----------|----------|
| >800 | any | **YES** |
| 500-800 | >7 | **YES** |
| 500-800 | ≤7 | **MAYBE** - only if reusable hooks |
| <500 | any | **NO** - organize inline |

- [ ] Component passes GATE 0? If **NO** → stop here, organize inline only

---

## Pre-Flight (Before Starting)

### Component Analysis
- [ ] Read the COMPLETE file (not just the beginning)
- [ ] Count total lines: `wc -l {file}`
- [ ] List all `useState` (how many? _____)
- [ ] List all `render{X}()` functions (how many? _____)
- [ ] Identify repeated JSX patterns (2+ times)
- [ ] Map external dependencies (hooks, utils, types)

### Check Shared Components
- [ ] Check `app/components/shared/hooks/` - does the hook already exist?
- [ ] Check `app/components/shared/molecules/` - does the molecule already exist?
- [ ] Check `app/components/ui/` - does the UI component exist?
- [ ] If a new shared component is needed → add to `docs/refactoring/SHARED_REQUESTS.md`

### Confirm Domain
- [ ] Identify correct domain: `{domain}/{feature}/`
- [ ] Verify no folder with the same name exists
- [ ] Confirm no files from ANOTHER domain will be touched

---

## Structure (Create Folders/Files)

### Create Base Structure
```
app/components/{domain}/{feature}/
├── types.ts
├── index.ts
├── {Feature}Template.tsx
├── hooks/
│   └── index.ts
├── molecules/
│   └── index.ts
└── organisms/
    └── index.ts
```

- [ ] Create folder `{domain}/{feature}/`
- [ ] Create `types.ts` with interfaces
- [ ] Create `index.ts` (barrel export)
- [ ] Create folder `hooks/` + `index.ts`
- [ ] Create folder `molecules/` + `index.ts` (if needed)
- [ ] Create folder `organisms/` + `index.ts`

---

## Extraction (Decompose the Component)

### 1. Types (types.ts) - CRITICAL ⚠️
- [ ] Move/create all Props interfaces
- [ ] Move/create data types (enums, unions)
- [ ] Move/create configurations (COLORS, ICONS, etc.)
- [ ] Export everything with `export`
- [ ] **MANDATORY VALIDATION:** After creating `data/*.ts`, verify ALL imported types exist in `types.ts`
  ```bash
  # List types imported in data/
  grep -h "from '../types'" {folder}/data/*.ts | grep -oE "{ [^}]+ }"
  # Check if they exist in types.ts
  grep "export interface\|export type" {folder}/types.ts
  ```
  **If any type is missing → ADD it before continuing**

### 2. Hooks (hooks/) - ⚠️ GATE 1 PER HOOK

**For EACH hook you are about to create, answer:**
```
Will this hook be used in ANOTHER component?
[ ] YES - where: ____________
[ ] NO → DO NOT create, keep useState inline
```

- [ ] **GATE 1 passed for all hooks?**
- [ ] Group related `useState` into custom hooks
- [ ] Naming: `use{Feature}{Concern}.ts`
  - Data: `use{Feature}Data.ts`
  - Filters: `use{Feature}Filters.ts`
  - Dialogs: `use{Dialog}Dialog.ts`
- [ ] Each hook returns an object with state + setters
- [ ] Export in `hooks/index.ts`

### 3. Molecules (molecules/) - If Needed
- [ ] Extract JSX patterns repeated 2+ times
- [ ] Small, stateless components
- [ ] Props well-defined in types.ts
- [ ] Export in `molecules/index.ts`

### 4. Organisms (organisms/)
- [ ] Each `render{X}()` becomes `{X}View.tsx` or `{X}Section.tsx`
- [ ] Receives props, does not use hooks directly (except UI state)
- [ ] Consistent naming: `{Feature}Header.tsx`, `{Feature}ListView.tsx`
- [ ] Export in `organisms/index.ts`

### 5. Template Orchestrator
- [ ] Import all hooks
- [ ] Import all organisms
- [ ] Composition only (no business logic)
- [ ] Layout and ordering of organisms
- [ ] Pass props to each organism

---

## Validation (Post-Extraction)

### TypeScript
- [ ] `npx tsc --noEmit` - 0 errors
- [ ] No `any` types (except when unavoidable)
- [ ] Props correctly typed

### Line Count
- [ ] Template orchestrator: **≤100 lines** (no state, composition only)
- [ ] Each hook: ≤150 lines
- [ ] Each molecule: ≤100 lines
- [ ] Each organism: ≤200 lines (exceptions documented)
- [ ] types.ts: no limit (configs can be large)

### Imports - CRITICAL ⚠️

**RULE: ALWAYS use `@/` aliases, NEVER relative paths for UI**

```typescript
// ✅ CORRECT
import { Icon } from '@/components/ui/icon';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

// ❌ WRONG - DO NOT use
import { Icon } from '../../../ui/icon';
import { Button } from '../../shared/ui/button';
```

- [ ] **Mandatory validation before finishing:**
  ```bash
  grep -rn "from '\.\./\.\./\.\." {created-folder}/
  ```
  If results are returned → **FIX before reporting completion**

- [ ] All imports from `@/components/ui/*` use alias
- [ ] No circular imports
- [ ] Barrel exports working (`import { X } from './hooks'`)
- [ ] Relative paths OK only for files within the same module

### Functionality
- [ ] Test in browser - renders identically to original?
- [ ] Test interactions - buttons, forms, dialogs work?
- [ ] Test edge cases - loading, empty, error states

### Consistency with Pattern
- [ ] Compare structure with `ops/users/`
- [ ] Naming conventions followed
- [ ] Barrel exports match the same pattern

---

## Finalization

### Documentation
- [ ] Update `docs/refactoring/COMPONENT_REFACTORING_ROADMAP.md`
  - [ ] Mark status as Done
  - [ ] Add line count (before → after)
  - [ ] Add structure of created files
- [ ] If shared component was created → document usage

### Git
- [ ] `git add` only files from the refactored domain
- [ ] Commit message: `refactor({domain}): decompose {Component} ({before}→{after} lines)`
- [ ] Do not commit files from other domains

### Cleanup
- [ ] Delete original file (if moved to new folder)
- [ ] Update imports in files that used the component
- [ ] Verify no import was broken

### AppRoutes.tsx - CRITICAL ⚠️

**If the component path changed (e.g., `templates/X.tsx` → `x-feature/X.tsx`):**

- [ ] **MANDATORY:** Update import in `app/components/AppRoutes.tsx`
  ```bash
  # Check if AppRoutes imports the old component
  grep "{ComponentName}" app/components/AppRoutes.tsx
  ```
- [ ] Fix the lazy import path:
  ```typescript
  // BEFORE (old path)
  const MyTemplate = React.lazy(() => import('./domain/templates/MyTemplate'));

  // AFTER (new path)
  const MyTemplate = React.lazy(() => import('./domain/my-feature/MyTemplate'));
  ```
- [ ] **Validate:** `npm run typecheck` must not have `Cannot find module` error

---

## GATE 2: Final Validation (MANDATORY)

```bash
# Count TOTAL lines of created folder
find {created-folder} -name "*.ts" -o -name "*.tsx" | xargs wc -l | tail -1
```

| Metric | Limit | If Failing |
|--------|-------|------------|
| Total lines | ≤ original | Simplify or revert |
| Files created | ≤7 | Consolidate |
| Hooks without external use | 0 | Move inline |

- [ ] **GATE 2 passed?** If not → simplify before committing

---

## Success Metrics

| Metric | Criterion | Check |
|--------|-----------|-------|
| **GATE 2: Total lines** | **≤ original** | [ ] |
| **GATE 2: Files** | **≤7** | [ ] |
| **GATE 2: Orphan hooks** | **0** | [ ] |
| Line reduction in template | ≥70% | [ ] |
| Template orchestrator | **≤100 lines** | [ ] |
| Largest organism | ≤200 lines | [ ] |
| TypeScript errors | 0 | [ ] |
| Import validation | 0 `../../../` | [ ] |
| Types consistency | All types in data/ exist in types.ts | [ ] |
| AppRoutes.tsx | Import updated (if path changed) | [ ] |
| Functionality | 100% identical | [ ] |

---

## Quick Reference

### Naming Conventions

```
Hooks:      use{Feature}{Concern}.ts     → useCoursesData.ts
Molecules:  {Pattern}.tsx                 → StatCard.tsx
Organisms:  {Feature}{Type}.tsx           → CoursesListView.tsx
Template:   {Feature}Template.tsx         → CoursesTemplate.tsx
Types:      types.ts                      → types.ts
Index:      index.ts                      → index.ts
```

### useState Extraction

```typescript
// BEFORE (in template)
const [search, setSearch] = useState('');
const [filters, setFilters] = useState({});

// AFTER (in hooks/useFilters.ts)
export function useFilters() {
  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState({});
  return { search, setSearch, filters, setFilters };
}
```

### render{X} Extraction

```typescript
// BEFORE (in template)
const renderHeader = () => <div>...</div>;

// AFTER (in organisms/Header.tsx)
export const Header: React.FC<HeaderProps> = (props) => <div>...</div>;
```

---

*Checklist v1.2 - Added critical validations: types consistency and AppRoutes.tsx*
*Based on 18+ refactored components with 91% average reduction*
