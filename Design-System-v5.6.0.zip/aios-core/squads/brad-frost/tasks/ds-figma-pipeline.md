# Configure Figma MCP + Design-to-Code Pipeline

> Task ID: brad-figma-pipeline
> Agent: Brad (Design System Architect)
> Version: 1.1.0
> **Execution Type:** `Agent`
> **Dependencies:** depends_on: `[ds-setup-design-system]` · enables: `[]` · workflow: `figma`
> **On Fail:** If MCP server connection fails → verify Figma API token and network. If component mapping <50% → generate gap report, do NOT proceed to token sync. If token drift >20% → halt sync, prompt user for canonical source.

## Description

Configure the Figma MCP Server to connect design files with AI coding tools. Establishes component mapping (Figma components → code components), token sync (Figma Variables → W3C DTCG), and design-to-code workflow.

## Prerequisites

- Figma file with component library
- Figma API access (personal access token)
- AI coding tool (Claude Code, Cursor, Windsurf)
- Design system setup completed (`*setup` command run successfully)

## Anti-Patterns

DO NOT:
- Map Figma components 1:1 by name alone — variant props and slot patterns differ between Figma and code
- Sync tokens bidirectionally without conflict resolution rules — one source must be canonical
- Skip the validation step — AI-generated code often uses hardcoded values instead of tokens
- Auto-sync in CI/CD without a dry-run mode — a bad sync can overwrite production tokens
- Assume Figma naming matches code naming — Figma uses "/" separators, code uses PascalCase

## Workflow

### Interactive Elicitation

1. **Gather Parameters**
   - Figma file URL or key
   - Code component library location
   - Target AI tool for integration
   - Token sync direction (Figma → code, code → Figma, bidirectional)

### Steps

1. **Setup Figma MCP Server**
   - Install Figma MCP Server package: `npm install @anthropic-ai/figma-mcp`
   - Configure Figma API token in MCP config (never hardcode — use environment variable `FIGMA_API_TOKEN`)
   - Connect to target Figma file using file key from URL
   - Query MCP server: request component list
   - Check: MCP server query returns component list with count > 0 — abort with "MCP server not responding or returned empty component list. Verify: 1) FIGMA_API_TOKEN is set, 2) file key is correct, 3) network allows api.figma.com"

2. **Create Component Mapping**
   - Extract all Figma component names from MCP response
   - For each Figma component, search code directory for matching component file (match by normalized name: `Icon/Arrow` → `ArrowIcon`)
   - Map Figma variants → code component props (e.g., Figma `State=Hover` → `isHovered={true}`)
   - Map Figma auto-layout properties → CSS: `layoutMode=HORIZONTAL` → `display: flex; flex-direction: row`, `layoutMode=VERTICAL` → `flex-direction: column`
   - List unmapped components in `figma-component-mapping.json` under `unmapped` key
   - Check: `(mapped / total) * 100 >= 80` — if below, log "Mapping coverage: {pct}% ({mapped}/{total}), unmapped: {list}" and warn user

3. **Configure Token Sync**
   - Export Figma Variables using MCP `getVariables` endpoint
   - Convert to W3C DTCG format: `{ "$value": "{value}", "$type": "{type}" }`
   - Diff against existing code tokens file (`tokens.yaml` or `tokens.json`)
   - For each mismatch: log `"{token_name}: Figma={figma_value}, Code={code_value}"`
   - Define conflict resolution: `canonical_source: "figma" | "code"` in sync config
   - If CI/CD sync: add `--dry-run` flag that logs changes without applying
   - Check: drift count == 0 — if drift > 0, log "Token drift detected: {N} mismatches" with full list

4. **Define Design-to-Code Workflow**
   - Developer selects Figma frame/component in Figma
   - Developer invokes AI tool with MCP context: "Generate code for this component using our design system"
   - AI tool queries MCP for: component name, props, tokens, layout
   - AI generates code using mapped component imports and token references (not hardcoded values)
   - Developer reviews: verify imports match DS components, verify no hardcoded colors/spacing
   - Check: sample Figma frame generates code using >=80% mapped components AND zero hardcoded token values — abort with "Pipeline failed: AI output uses {N} unmapped components and {M} hardcoded values"

5. **Validate Round-Trip Fidelity**
   - Select 3 representative Figma frames: 1 simple (single component), 1 medium (card/form), 1 complex (page layout)
   - Generate code for each via the pipeline
   - Score each: `fidelity = (correct_components + correct_tokens + correct_layout) / (total_components + total_tokens + total_layout_rules) * 100`
   - Target: fidelity >= 80% on all 3 frames
   - Document mismatches in `figma-fidelity-report.md` with specific fixes per mismatch
   - Update .state.yaml with `figma_pipeline: configured, fidelity: {score}%`

## Output

- Figma MCP Server configured and connected
- `figma-component-mapping.json` — Figma → code component map with `mapped` and `unmapped` sections
- `figma-token-sync-config.yaml` — Token sync configuration with canonical source and conflict rules
- `figma-fidelity-report.md` — Validation results for 3 sample frames with mismatch fixes
- `figma-pipeline-guide.md` — Team workflow documentation
- `.state.yaml` updated

## Examples

### Example 1: Component Mapping Output

**Input:** Figma file with 24 components, code library at `src/components/`

**Output (`figma-component-mapping.json`):**
```json
{
  "mapping_coverage": "87.5%",
  "mapped": [
    { "figma": "Button/Primary", "code": "src/components/atoms/Button.tsx", "props_mapped": ["variant=primary", "size", "disabled"] },
    { "figma": "Input/Text", "code": "src/components/atoms/TextInput.tsx", "props_mapped": ["placeholder", "error", "disabled"] },
    { "figma": "Card/Product", "code": "src/components/molecules/ProductCard.tsx", "props_mapped": ["title", "image", "price"] }
  ],
  "unmapped": [
    { "figma": "Icon/Custom", "reason": "No code equivalent — needs creation" },
    { "figma": "Divider/Decorative", "reason": "Figma-only element, not in DS" },
    { "figma": "Badge/New", "reason": "Name mismatch — code has 'Tag' component" }
  ]
}
```

### Example 2: Token Drift Report

**Input:** Figma Variables vs `tokens.yaml`

**Output (console):**
```
Token drift detected: 4 mismatches

  color.primary:    Figma=#2563EB  Code=#3B82F6  → MISMATCH (canonical: Figma wins)
  spacing.lg:       Figma=32px     Code=24px     → MISMATCH (canonical: Figma wins)
  font.size.sm:     Figma=14px     Code=14px     → OK
  border.radius.md: Figma=8px      Code=6px      → MISMATCH (canonical: Code wins — intentional override)
  shadow.card:      Figma=missing  Code=0 4 6    → MISMATCH (Figma missing — add to Figma)

Action: Apply 2 Figma→Code syncs, 1 Code→Figma backfill, 1 documented override
```

## Failure Handling

- **MCP Server connection timeout:** If Figma MCP Server does not respond within 10s or returns empty data, verify: 1) `FIGMA_API_TOKEN` environment variable is set, 2) file key is correct (extract from URL: `figma.com/file/{KEY}/...`), 3) network allows `api.figma.com:443`. Exit with specific error message.
- **Component mapping below 50%:** Generate unmapped component report with reasons per component. Do NOT proceed to token sync — mapping must be >=50% to continue. Suggest: create placeholder components or align naming conventions first.
- **Critical token drift >20%:** Halt sync immediately. Present drift report. Prompt user to choose canonical source per token category (colors from Figma, spacing from code, etc.). Document in `figma-token-sync-config.yaml`.
- **AI-generated code uses wrong components:** If sample generates 3+ unmapped components or hardcoded values, flag as fidelity failure. Include side-by-side comparison (expected vs actual) in fidelity report. Root causes: incomplete mapping, missing variants, or AI context window limitations.

## Success Criteria

- [ ] MCP Server returns accurate Figma component data (component count > 0)
- [ ] >80% of Figma components mapped to code equivalents
- [ ] Token values synchronized (zero drift after sync, or all drifts documented with canonical source)
- [ ] AI-generated code uses correct DS components on 3 sample frames (fidelity >= 80%)
- [ ] Pipeline guide documented for team adoption
